<script src="{{ asset('admin') }}/app-assets/vendors/js/vendors.min.js"></script>
    <script src="{{ asset('admin') }}/app-assets/vendors/js/charts/apexcharts.min.js"></script>
    <script src="{{ asset('admin') }}/app-assets/vendors/js/extensions/toastr.min.js"></script>
    <script src="{{ asset('admin') }}/app-assets/vendors/js/charts/chart.min.js"></script>
    <script src="{{ asset('admin') }}/app-assets/js/core/app-menu.min.js"></script>
    <script src="{{ asset('admin') }}/app-assets/js/core/app.min.js"></script>
    <script src="{{ asset('admin') }}/app-assets/js/scripts/customizer.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
